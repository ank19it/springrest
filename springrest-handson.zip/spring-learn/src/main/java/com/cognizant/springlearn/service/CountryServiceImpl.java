package com.cognizant.springlearn.service;

import com.cognizant.springlearn.Country;

public class CountryServiceImpl implements CountryService {

	@Override
	public Country addCountry(Country country) {
		// TODO Auto-generated method stub
		return null;
	}

}
