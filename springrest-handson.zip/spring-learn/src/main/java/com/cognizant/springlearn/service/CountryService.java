package com.cognizant.springlearn.service;

import com.cognizant.springlearn.Country;

public interface CountryService {
	
	public Country addCountry(Country country);

}
